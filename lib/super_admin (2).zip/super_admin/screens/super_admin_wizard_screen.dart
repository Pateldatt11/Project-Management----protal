import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wizard_state_provider.dart';

class SuperAdminWizardScreen extends StatelessWidget {
  const SuperAdminWizardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<WizardStateProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Create New Company Profile"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      backgroundColor: const Color(0xFFF5F6FA),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Theme(
              data: Theme.of(context).copyWith(
                colorScheme: const ColorScheme.light(
                  primary: Color(0xFF673AB7),
                ),
              ),
              child: Stepper(
                type: StepperType.vertical,
                currentStep: state.currentStep,
                onStepTapped: (step) => state.jumpToStep(step), // Uses your jumpToStep method
                onStepContinue: state.currentStep < 4 
                    ? () {
                        // Your provider's nextStep() caps at 3, so we manually jump to 4 for the review screen
                        if (state.currentStep == 3) {
                          state.jumpToStep(4);
                        } else {
                          state.nextStep();
                        }
                      } 
                    : null,
                onStepCancel: state.currentStep > 0 ? state.previousStep : null,
                controlsBuilder: (context, details) {
                  if (state.currentStep == 4) return const SizedBox.shrink();
                  
                  return Padding(
                    padding: const EdgeInsets.only(top: 24.0),
                    child: Row(
                      children: [
                        ElevatedButton(
                          onPressed: details.onStepContinue,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF673AB7),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                          ),
                          child: const Text('Continue'),
                        ),
                        const SizedBox(width: 16),
                        if (state.currentStep > 0)
                          TextButton(
                            onPressed: details.onStepCancel,
                            child: const Text('Back', style: TextStyle(color: Colors.grey)),
                          ),
                      ],
                    ),
                  );
                },
                steps: [
                  _buildStep1(state),
                  _buildStep2(state),
                  _buildStep3(state),
                  _buildStep4(state),
                  _buildStep5(context, state),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================
  // Step 1 - Company Information
  // ===========================================================
  Step _buildStep1(WizardStateProvider state) {
    return Step(
      title: const Text('Company Information', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 0,
      state: state.currentStep > 0 ? StepState.complete : StepState.indexed,
      content: Column(
        children: [
          TextFormField(
            controller: state.companyNameController,
            decoration: const InputDecoration(labelText: 'Target Workspace Name', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: state.ownerNameController,
            decoration: const InputDecoration(labelText: 'Primary Owner Name', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: state.emailController,
            decoration: const InputDecoration(labelText: 'Admin Email Address', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: state.phoneController,
            decoration: const InputDecoration(labelText: 'Phone Number (Optional)', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
        ],
      ),
    );
  }

  // ===========================================================
  // Step 2 - Subscription
  // ===========================================================
  Step _buildStep2(WizardStateProvider state) {
    return Step(
      title: const Text('Subscription Plan & Constraints', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 1,
      state: state.currentStep > 1 ? StepState.complete : StepState.indexed,
      content: Column(
        children: [
          DropdownButtonFormField<String>(
            value: state.selectedPlan,
            decoration: const InputDecoration(labelText: 'Subscription Tier', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            items: const [
              DropdownMenuItem(value: 'free', child: Text('Free Allocation')),
              DropdownMenuItem(value: 'pro', child: Text('Pro Tier')),
              DropdownMenuItem(value: 'enterprise', child: Text('Enterprise Tier')),
            ],
            onChanged: (val) {
              if (val != null) state.setPlan(val);
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: state.employeeLimit.toString(),
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Max Employee Limit', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.setEmployeeLimit(int.tryParse(val) ?? 10),
          ),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: state.storageLimit.toString(),
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Storage Limit (GB)', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.setStorageLimit(int.tryParse(val) ?? 5),
          ),
        ],
      ),
    );
  }

  // ===========================================================
  // Step 3 - Authentication
  // ===========================================================
  Step _buildStep3(WizardStateProvider state) {
    return Step(
      title: const Text('Security & Authentication', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 2,
      state: state.currentStep > 2 ? StepState.complete : StepState.indexed,
      content: Column(
        children: [
          TextFormField(
            controller: state.passwordController,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Initial Admin Password', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: state.confirmPasswordController,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Confirm Password', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
          ),
        ],
      ),
    );
  }

  // ===========================================================
  // Step 4 - Modules Framework
  // ===========================================================
  Step _buildStep4(WizardStateProvider state) {
    return Step(
      title: const Text('Initialize Modules Framework', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 3,
      state: state.currentStep > 3 ? StepState.complete : StepState.indexed,
      content: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(bottom: 16.0),
              child: Text(
                "Toggle the core features to provision for this workspace:",
                style: TextStyle(color: Colors.grey, fontSize: 14),
              ),
            ),
            SwitchListTile(
              activeColor: const Color(0xFF673AB7),
              title: const Text('Projects Module'),
              value: state.enableProjects,
              onChanged: state.toggleProjects,
            ),
            const Divider(height: 1),
            SwitchListTile(
              activeColor: const Color(0xFF673AB7),
              title: const Text('Timeline Module'),
              value: state.enableTimeline,
              onChanged: state.toggleTimeline,
            ),
            const Divider(height: 1),
            SwitchListTile(
              activeColor: const Color(0xFF673AB7),
              title: const Text('Reports Module'),
              value: state.enableReports,
              onChanged: state.toggleReports,
            ),
            const Divider(height: 1),
            SwitchListTile(
              activeColor: const Color(0xFF673AB7),
              title: const Text('Notifications Module'),
              value: state.enableNotifications,
              onChanged: state.toggleNotifications,
            ),
            const Divider(height: 1),
            SwitchListTile(
              activeColor: const Color(0xFF673AB7),
              title: const Text('Appraisal Module'),
              value: state.enableAppraisal,
              onChanged: state.toggleAppraisal,
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================
  // Step 5 - Review System Parameters
  // ===========================================================
  Step _buildStep5(BuildContext context, WizardStateProvider state) {
    return Step(
      title: const Text('Review System Parameters', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 4,
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Text("Target Workspace: ${state.companyNameController.text}", style: const TextStyle(fontSize: 15, height: 1.8)),
          Text("Assigned Tier: ${state.selectedPlan.toUpperCase()}", style: const TextStyle(fontSize: 15, height: 1.8)),
          Text("Infrastructure Owner: [${state.emailController.text}]", style: const TextStyle(fontSize: 15, height: 1.8)),
          const SizedBox(height: 24),

          // Error Display
          if (state.errorMessage != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 24),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.1),
                border: Border.all(color: Colors.redAccent),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.redAccent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      state.errorMessage!,
                      style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ],

          Row(
            children: [
              SizedBox(
                height: 48,
                width: 140,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF673AB7),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: state.isLoading 
                      ? null 
                      : () async {
                          // TODO: Replace these hardcoded platform admin values 
                          // with the actual logged-in super admin's credentials via AuthProvider
                          bool success = await state.createCompany(
                            platformAdminUid: 'super_admin_uid_here',
                            platformAdminName: 'Super Admin',
                            platformAdminEmail: 'admin@freelens.com',
                          );

                          if (success && context.mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Workspace Provisioned Successfully!")),
                            );
                          }
                        },
                  child: state.isLoading 
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) 
                      : const Text("Provision"),
                ),
              ),
              const SizedBox(width: 16),
              TextButton(
                onPressed: () => state.jumpToStep(3),
                child: const Text("Back", style: TextStyle(color: Colors.grey)),
              )
            ],
          ),
        ],
      ),
    );
  }
}