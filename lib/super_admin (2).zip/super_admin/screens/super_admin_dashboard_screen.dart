import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Added Auth import for logout
import 'package:project_management_dashboard/super_admin/screens/super_admin_wizard_screen.dart';

class SuperAdminDashboardScreen extends StatefulWidget {
  const SuperAdminDashboardScreen({Key? key}) : super(key: key);

  @override
  State<SuperAdminDashboardScreen> createState() => _SuperAdminDashboardScreenState();
}

class _SuperAdminDashboardScreenState extends State<SuperAdminDashboardScreen> {
  int _selectedIndex = 0;

  final List<Widget> _views = [
    const DashboardOverviewView(),
    const CompaniesView(),
    const PlansBillingView(),
    const AuditLogsView(),
    const BackendHealthView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Container(
            width: 260,
            color: const Color(0xFF1E1E26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text(
                    'Freelens Admin',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 16),
                _buildSidebarItem(Icons.dashboard, 'Dashboard', 0),
                _buildSidebarItem(Icons.business, 'Companies', 1),
                _buildSidebarItem(Icons.credit_card, 'Plans & Billing', 2),
                _buildSidebarItem(Icons.assignment, 'Audit Logs', 3),
                _buildSidebarItem(Icons.dns, 'Backend Health', 4),
                
                // Spacer pushes the logout button to the absolute bottom of the sidebar
                const Spacer(),
                const Divider(color: Colors.white24, height: 1),
                _buildLogoutButton(),
                const SizedBox(height: 16),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: const Color(0xFFF5F6FA),
              padding: const EdgeInsets.all(32.0),
              child: _views[_selectedIndex], 
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebarItem(IconData icon, String title, int index) {
    bool isActive = _selectedIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => setState(() => _selectedIndex = index),
        child: Container(
          color: isActive ? Colors.blueAccent.withOpacity(0.2) : Colors.transparent,
          child: ListTile(
            leading: Icon(icon, color: isActive ? Colors.blueAccent : Colors.white70),
            title: Text(
              title,
              style: TextStyle(
                color: isActive ? Colors.blueAccent : Colors.white70,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================
  // LOGOUT BUTTON WIDGET
  // ==========================================
  Widget _buildLogoutButton() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () async {
          // Signs the user out of Firebase. 
          // The StreamBuilder in main.dart will detect this and auto-route to Login.
          await FirebaseAuth.instance.signOut();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          child: Row(
            children: const [
              Icon(Icons.logout, color: Colors.redAccent),
              SizedBox(width: 32),
              Text(
                'Log Out',
                style: TextStyle(
                  color: Colors.redAccent,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// VIEW 1: Dashboard Overview (Live Data)
// ==========================================
class DashboardOverviewView extends StatelessWidget {
  const DashboardOverviewView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Global Platform Overview', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
            ElevatedButton.icon(
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Provision New Company', style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16)),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SuperAdminWizardScreen())),
            ),
          ],
        ),
        const SizedBox(height: 32),
        Row(
          children: [
            // Live Tenant Count
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('companies').snapshots(),
              builder: (context, snapshot) {
                int count = snapshot.hasData ? snapshot.data!.docs.length : 0;
                return _buildMetricCard('Total Tenants', '$count Companies', Icons.business, Colors.blue);
              }
            ),
            const SizedBox(width: 24),
            // Live User Count
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').snapshots(),
              builder: (context, snapshot) {
                int count = snapshot.hasData ? snapshot.data!.docs.length : 0;
                return _buildMetricCard('Active Users', '$count Users', Icons.people, Colors.green);
              }
            ),
            const SizedBox(width: 24),
            // Live Gateway Status (Looking at a config doc)
            StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('system').doc('health').snapshots(),
              builder: (context, snapshot) {
                String status = snapshot.hasData && snapshot.data!.exists 
                    ? (snapshot.data!.data() as Map<String, dynamic>)['gatewayStatus'] ?? 'Unknown'
                    : 'Awaiting Data';
                return _buildMetricCard('API Gateway Status', status, Icons.check_circle, Colors.orange);
              }
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMetricCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
        child: Row(
          children: [
            CircleAvatar(radius: 28, backgroundColor: color.withOpacity(0.1), child: Icon(icon, color: color, size: 28)),
            const SizedBox(width: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FontWeight.w500)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// VIEW 2: Companies / Tenant Directory (Live Data)
// ==========================================
class CompaniesView extends StatelessWidget {
  const CompaniesView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Tenant Directory', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
        const SizedBox(height: 32),
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('companies').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
                
                final docs = snapshot.data?.docs ?? [];
                if (docs.isEmpty) return const Center(child: Text("No companies provisioned yet."));

                return SingleChildScrollView(
                  child: DataTable(
                    columns: const [
                      DataColumn(label: Text('Company Name', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Industry', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
                    ],
                    rows: docs.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return DataRow(
                        cells: [
                          DataCell(Text(data['name'] ?? 'Unnamed')),
                          DataCell(Text(data['industry'] ?? 'General')),
                          DataCell(Chip(
                            label: Text(data['status'] ?? 'Active', style: const TextStyle(color: Colors.white, fontSize: 12)),
                            backgroundColor: (data['status'] ?? '').toString().toLowerCase() == 'active' ? Colors.green : Colors.redAccent,
                          )),
                          DataCell(Row(
                            children: [
                              IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () {}),
                              // Delete Logic
                              IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () async {
                                await FirebaseFirestore.instance.collection('companies').doc(doc.id).delete();
                              }),
                            ],
                          )),
                        ],
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

// ==========================================
// VIEW 3: Plans & Billing (Live Data)
// ==========================================
class PlansBillingView extends StatelessWidget {
  const PlansBillingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Plans & Billing', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
        const SizedBox(height: 32),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('plans').snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
              
              final docs = snapshot.data?.docs ?? [];
              if (docs.isEmpty) return const Center(child: Text("No plans configured in Firestore (/plans)."));

              return Row(
                children: docs.map((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 24.0),
                      child: Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: data['isPopular'] == true ? Border.all(color: Colors.blueAccent, width: 2) : null,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (data['isPopular'] == true)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                margin: const EdgeInsets.only(bottom: 12),
                                decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(4)),
                                child: const Text('Most Popular', style: TextStyle(color: Colors.white, fontSize: 12)),
                              ),
                            Text(data['name'] ?? 'Unnamed Plan', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 8),
                            Text(data['price'] ?? '\$0', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                            const Divider(height: 32),
                            Text(data['description'] ?? 'No details provided.', style: const TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        )
      ],
    );
  }
}

// ==========================================
// VIEW 4: Audit Logs (Live Data)
// ==========================================
class AuditLogsView extends StatelessWidget {
  const AuditLogsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('System Audit Logs', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
        const SizedBox(height: 32),
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('audit_logs').orderBy('timestamp', descending: true).snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                
                final docs = snapshot.data?.docs ?? [];
                if (docs.isEmpty) return const Center(child: Text("No system logs found in Firestore (/audit_logs)."));

                return ListView.separated(
                  itemCount: docs.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    final Timestamp? ts = data['timestamp'] as Timestamp?;
                    return ListTile(
                      leading: const CircleAvatar(backgroundColor: Colors.blueGrey, child: Icon(Icons.history, color: Colors.white)),
                      title: Text(data['action'] ?? 'Unknown Action'),
                      subtitle: Text(ts != null ? ts.toDate().toString() : 'No timestamp'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

// ==========================================
// VIEW 5: Backend Health (Live Data)
// ==========================================
class BackendHealthView extends StatelessWidget {
  const BackendHealthView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Backend Infrastructure Health', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF333333))),
        const SizedBox(height: 32),
        StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('system').doc('health').snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const CircularProgressIndicator();
            
            final data = snapshot.hasData && snapshot.data!.exists 
                ? snapshot.data!.data() as Map<String, dynamic> 
                : {};

            if (data.isEmpty) return const Text("System health telemetry missing (/system/health).");

            return Row(
              children: [
                _buildStatusCard('Database Connection', data['database'] ?? 'Unknown', _getColor(data['database'])),
                const SizedBox(width: 24),
                _buildStatusCard('Auth Service', data['auth'] ?? 'Unknown', _getColor(data['auth'])),
                const SizedBox(width: 24),
                _buildStatusCard('Storage Buckets', data['storage'] ?? 'Unknown', _getColor(data['storage'])),
              ],
            );
          },
        ),
      ],
    );
  }

  Color _getColor(String? status) {
    if (status?.toLowerCase() == 'online') return Colors.green;
    if (status?.toLowerCase() == 'degraded') return Colors.orange;
    return Colors.red;
  }

  Widget _buildStatusCard(String service, String status, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border(left: BorderSide(color: color, width: 6)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.grey)),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.circle, color: color, size: 12),
                const SizedBox(width: 8),
                Text(status.toUpperCase(), style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
              ],
            )
          ],
        ),
      ),
    );
  }
}