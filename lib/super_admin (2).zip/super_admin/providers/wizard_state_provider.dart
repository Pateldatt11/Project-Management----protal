import 'package:flutter/material.dart';

import '../models/company_request_model.dart';
import '../services/super_admin_api_service.dart';

class WizardStateProvider extends ChangeNotifier {
  WizardStateProvider({
    SuperAdminApiService? apiService,
  }) : _apiService = apiService ?? SuperAdminApiService();

  final SuperAdminApiService _apiService;

  // ===========================================================
  // Wizard State
  // ===========================================================

  int _currentStep = 0;
  bool _isLoading = false;
  String? _errorMessage;

  int get currentStep => _currentStep;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // ===========================================================
  // Step 1 - Company Information
  // ===========================================================

  final companyNameController = TextEditingController();
  final ownerNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  String country = "India";

  // ===========================================================
  // Step 2 - Subscription
  // ===========================================================

  String selectedPlan = "free";

  int employeeLimit = 10;
  int storageLimit = 5;

  // ===========================================================
  // Step 3 - Authentication
  // ===========================================================

  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  // ===========================================================
  // Step 4 - Modules
  // ===========================================================

  bool enableProjects = true;
  bool enableTimeline = true;
  bool enableReports = true;
  bool enableNotifications = true;
  bool enableAppraisal = false;

  // ===========================================================
  // Navigation
  // ===========================================================

  void nextStep() {
    if (_currentStep < 3) {
      _currentStep++;
      notifyListeners();
    }
  }

  void previousStep() {
    if (_currentStep > 0) {
      _currentStep--;
      notifyListeners();
    }
  }

  void jumpToStep(int step) {
    _currentStep = step;
    notifyListeners();
  }

  // ===========================================================
  // Loading
  // ===========================================================

  void _startLoading() {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
  }

  void _stopLoading() {
    _isLoading = false;
    notifyListeners();
  }

  void setError(String message) {
    _errorMessage = message;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // ===========================================================
  // Validation
  // ===========================================================

  bool validateStepOne() {
    if (companyNameController.text.trim().isEmpty) {
      setError("Company name is required.");
      return false;
    }

    if (ownerNameController.text.trim().isEmpty) {
      setError("Owner name is required.");
      return false;
    }

    if (emailController.text.trim().isEmpty) {
      setError("Email is required.");
      return false;
    }

    clearError();
    return true;
  }

  bool validateStepTwo() {
    if (employeeLimit <= 0) {
      setError("Employee limit must be greater than zero.");
      return false;
    }

    if (storageLimit <= 0) {
      setError("Storage limit must be greater than zero.");
      return false;
    }

    clearError();
    return true;
  }

  bool validateStepThree() {
    if (passwordController.text.length < 6) {
      setError("Password must contain at least 6 characters.");
      return false;
    }

    if (passwordController.text != confirmPasswordController.text) {
      setError("Passwords do not match.");
      return false;
    }

    clearError();
    return true;
  }

  bool validateAll() {
    return validateStepOne() &&
        validateStepTwo() &&
        validateStepThree();
  }

  // ===========================================================
  // Build Request Model
  // ===========================================================

  CompanyRequestModel buildRequest() {
    return CompanyRequestModel(
      companyName: companyNameController.text.trim(),
      country: country,
      plan: selectedPlan,
      employeeLimit: employeeLimit,
      storageLimit: storageLimit,
      ownerName: ownerNameController.text.trim(),
      email: emailController.text.trim(),
      phone: phoneController.text.trim(),
      enableProjects: enableProjects,
      enableTimeline: enableTimeline,
      enableAppraisal: enableAppraisal,
      enableReports: enableReports,
      enableNotifications: enableNotifications, password: '',
    );
  }

  // ===========================================================
  // Create Company
  // ===========================================================

  Future<bool> createCompany({
    required String platformAdminUid,
    required String platformAdminName,
    required String platformAdminEmail,
  }) async {
    if (!validateAll()) {
      return false;
    }

    _startLoading();

    try {
      final request = buildRequest();

      // FIXED: Restored 'createCompany' and correctly labeled the 'password' parameter
      await _apiService.createCompany(
        request: request,
        password: passwordController.text.trim(),
        platformAdminUid: platformAdminUid,
        platformAdminName: platformAdminName,
        platformAdminEmail: platformAdminEmail, adminPassword: '',
      );

      resetWizard();
      _stopLoading();
      return true;
      
    } catch (e) {
      _stopLoading();
      setError(e.toString().replaceFirst('Exception: ', ''));
      return false;
    }
  }

  // ===========================================================
  // Reset Wizard
  // ===========================================================

  void resetWizard() {
    _currentStep = 0;

    companyNameController.clear();
    ownerNameController.clear();
    emailController.clear();
    phoneController.clear();

    passwordController.clear();
    confirmPasswordController.clear();

    country = "India";
    selectedPlan = "free";
    employeeLimit = 10;
    storageLimit = 5;

    enableProjects = true;
    enableTimeline = true;
    enableReports = true;
    enableNotifications = true;
    enableAppraisal = false;

    _errorMessage = null;
    notifyListeners();
  }

  // ===========================================================
  // Setters
  // ===========================================================

  void setCountry(String value) {
    country = value;
    notifyListeners();
  }

  void setPlan(String value) {
    selectedPlan = value;
    notifyListeners();
  }

  void setEmployeeLimit(int value) {
    employeeLimit = value;
    notifyListeners();
  }

  void setStorageLimit(int value) {
    storageLimit = value;
    notifyListeners();
  }

  void toggleProjects(bool value) {
    enableProjects = value;
    notifyListeners();
  }

  void toggleTimeline(bool value) {
    enableTimeline = value;
    notifyListeners();
  }

  void toggleReports(bool value) {
    enableReports = value;
    notifyListeners();
  }

  void toggleNotifications(bool value) {
    enableNotifications = value;
    notifyListeners();
  }

  void toggleAppraisal(bool value) {
    enableAppraisal = value;
    notifyListeners();
  }

  // ===========================================================
  // Dispose
  // ===========================================================

  @override
  void dispose() {
    companyNameController.dispose();
    ownerNameController.dispose();
    emailController.dispose();
    phoneController.dispose();

    passwordController.dispose();
    confirmPasswordController.dispose();

    super.dispose();
  }
}