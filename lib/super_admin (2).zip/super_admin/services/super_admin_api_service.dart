import '../models/company_request_model.dart';
import 'company_provisioning_service.dart';

class SuperAdminApiService {
  SuperAdminApiService({
    CompanyProvisioningService? provisioningService,
  }) : _provisioningService =
            provisioningService ?? CompanyProvisioningService();

  final CompanyProvisioningService _provisioningService;

  /// Create a new company
  Future<String> createCompany({
    required CompanyRequestModel request,
    required String adminPassword,

    /// Logged-in Platform Super Admin
    required String platformAdminUid,
    required String platformAdminName,
    required String platformAdminEmail, required String password,
  }) async {
    return await _provisioningService.provisionCompany(
      request: request,
      adminPassword: adminPassword,
      platformAdminUid: platformAdminUid,
      platformAdminName: platformAdminName,
      platformAdminEmail: platformAdminEmail,
    );
  }
}