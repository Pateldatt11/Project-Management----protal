import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/audit_log_model.dart';
import '../models/company_admin_model.dart';
import '../models/company_model.dart';
import '../models/company_request_model.dart';
import '../models/subscription_model.dart';

class CompanyProvisioningService {
  CompanyProvisioningService({
    FirebaseFirestore? firestore,
    FirebaseAuth? auth,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  CollectionReference<Map<String, dynamic>> get _companies =>
      _firestore.collection('companies');

  CollectionReference<Map<String, dynamic>> get _users =>
      _firestore.collection('users');

  CollectionReference<Map<String, dynamic>> get _auditLogs =>
      _firestore.collection('auditLogs');

  /// ============================================================
  /// Main Entry (Fixed Scope and Null-Safety Alignment)
  /// ============================================================
  Future<String> provisionCompany({
    required CompanyRequestModel request,
    required String adminPassword,
    required String platformAdminUid,
    required String platformAdminName,
    required String platformAdminEmail,
  }) async {
    UserCredential? credential;

    try {
      // 1. Validate Request
      await validateRequest(request);

      // 2. Create Firebase Auth Company Admin
      credential = await createCompanyAdmin(
        request.email,
        adminPassword,
      );

      if (credential.user == null) {
        throw Exception("Failed to obtain the provisioned user ID from Firebase Auth.");
      }
      final String adminUid = credential.user!.uid;

      // 3. Generate IDs
      final String companyId = generateCompanyId();

      // 4. Build Models
      final company = buildCompany(
        companyId: companyId,
        adminUid: adminUid,
        request: request,
      );

      final admin = buildCompanyAdmin(
        uid: adminUid,
        companyId: companyId,
        request: request,
      );

      final subscription = buildSubscription(
        companyId: companyId,
        request: request,
      );

      final audit = buildAuditLog(
        companyId: companyId,
        companyName: request.companyName,
        performedByUid: platformAdminUid,
        performedByName: platformAdminName,
        performedByEmail: platformAdminEmail,
      );

      // 5. Firestore Batch Action Scope
      final WriteBatch batch = _firestore.batch();

      // Company Document allocation
      final companyRef = _companies.doc(companyId);
      batch.set(companyRef, company.toMap());

      // Global User System Registration
      final userRef = _users.doc(adminUid);
      batch.set(userRef, admin.toMap());

      // Company Specific Member Matrix Isolation
      final memberRef = companyRef.collection('members').doc(adminUid);
      batch.set(memberRef, admin.toMap());

      // Subscription Node
      final subscriptionRef = companyRef.collection('subscription').doc('current');
      batch.set(subscriptionRef, subscription.toMap());

      // Configuration Modules Framework Bootstrap Settings Map
      final settingsRef = companyRef.collection('settings').doc('general');
      batch.set(settingsRef, {
        "companyId": companyId,
        "companyName": request.companyName,
        "country": request.country,
        "plan": request.plan,
        "employeeLimit": request.employeeLimit,
        "storageLimit": request.storageLimit,
        "modules": {
          "projects": request.enableProjects,
          "timeline": request.enableTimeline,
          "appraisal": request.enableAppraisal,
          "reports": request.enableReports,
          "notifications": request.enableNotifications,
        },
        "createdAt": DateTime.now().toIso8601String(),
      });

      // Platform Integrity Audit Logging
      final auditRef = _auditLogs.doc(audit.id);
      batch.set(auditRef, audit.toMap());

      // 6. Commit Batch Sequence Transaction
      await batch.commit();

      // 7. Complete return value
      return companyId;
    } on FirebaseAuthException catch (e) {
      throw Exception(_mapFirebaseAuthError(e));
    } catch (e) {
      throw Exception(e.toString());
    }
  }

  /// ============================================================
  /// Helper Methods
  /// ============================================================
  String generateCompanyId() {
    final now = DateTime.now();
    final random = Random().nextInt(99999);

    return 'CMP'
        '${now.year}'
        '${now.month.toString().padLeft(2, '0')}'
        '${now.day.toString().padLeft(2, '0')}'
        '_'
        '${random.toString().padLeft(5, '0')}';
  }

  String generateSubscriptionId() {
    return 'SUB_${DateTime.now().millisecondsSinceEpoch}';
  }

  String generateAuditId() {
    return 'AUDIT_${DateTime.now().millisecondsSinceEpoch}';
  }

  Future<bool> companyExists(String companyName) async {
    final snapshot = await _companies
        .where('companyName', isEqualTo: companyName)
        .limit(1)
        .get();

    return snapshot.docs.isNotEmpty;
  }

  Future<bool> emailExists(String email) async {
    final snapshot = await _users
        .where('email', isEqualTo: email)
        .limit(1)
        .get();

    return snapshot.docs.isNotEmpty;
  }

  Future<void> validateRequest(CompanyRequestModel request) async {
    if (request.companyName.trim().isEmpty) {
      throw Exception("Company name is required.");
    }

    if (request.ownerName.trim().isEmpty) {
      throw Exception("Owner name is required.");
    }

    if (request.email.trim().isEmpty) {
      throw Exception("Admin email is required.");
    }

    if (await companyExists(request.companyName)) {
      throw Exception("A company with this name already exists.");
    }

    if (await emailExists(request.email)) {
      throw Exception("This email is already registered.");
    }
  }

  Future<UserCredential> createCompanyAdmin(String email, String password) async {
    return await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  CompanyModel buildCompany({
    required String companyId,
    required String adminUid,
    required CompanyRequestModel request,
  }) {
    final now = DateTime.now();

    return CompanyModel(
      id: companyId,
      companyName: request.companyName,
      legalCompanyName: request.companyName,
      industry: "Technology",
      companySize: "",
      description: "",
      email: request.email,
      phone: request.phone ?? '',
      website: "",
      address: "",
      city: "",
      state: "",
      country: request.country,
      postalCode: "",
      adminUid: adminUid,
      adminName: request.ownerName,
      adminEmail: request.email,
      planId: request.plan,
      employeeLimit: request.employeeLimit,
      storageLimit: request.storageLimit,
      projectLimit: 100,
      createdAt: now,
      updatedAt: now,
    );
  }

  CompanyAdminModel buildCompanyAdmin({
    required String uid,
    required String companyId,
    required CompanyRequestModel request,
  }) {
    final now = DateTime.now();

    return CompanyAdminModel(
      uid: uid,
      fullName: request.ownerName,
      email: request.email,
      phone: request.phone ?? '',
      companyId: companyId,
      companyName: request.companyName,
      createdAt: now,
      updatedAt: now,
    );
  }

  SubscriptionModel buildSubscription({
    required String companyId,
    required CompanyRequestModel request,
  }) {
    final now = DateTime.now();

    return SubscriptionModel(
      id: generateSubscriptionId(),
      companyId: companyId,
      planId: request.plan,
      planName: request.plan,
      maxUsers: request.employeeLimit,
      maxProjects: 100,
      storageLimitGB: request.storageLimit,
      price: 0,
      billingCycle: 'monthly',
      startDate: now,
      expiryDate: now.add(const Duration(days: 30)),
      createdAt: now,
      updatedAt: now,
    );
  }

  AuditLogModel buildAuditLog({
    required String companyId,
    required String companyName,
    required String performedByUid,
    required String performedByName,
    required String performedByEmail,
  }) {
    return AuditLogModel(
      id: generateAuditId(),
      action: AuditAction.companyCreated,
      companyId: companyId,
      companyName: companyName,
      performedByUid: performedByUid,
      performedByName: performedByName,
      performedByEmail: performedByEmail,
      description: "Platform Super Admin created a new company.",
      createdAt: DateTime.now(),
    );
  }

  String _mapFirebaseAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return "This email address is already in use by another account.";
      case 'weak-password':
        return "The password provided is too weak.";
      case 'invalid-email':
        return "The email address layout format is invalid.";
      default:
        return e.message ?? "An unexpected authentication processing error occurred.";
    }
  }
} // Ends the CompanyProvisioningService class definition block safely.