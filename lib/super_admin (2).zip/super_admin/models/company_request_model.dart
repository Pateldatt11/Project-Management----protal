import 'dart:convert';

class CompanyRequestModel {
  // =========================
  // Step 1 : Company Details
  // =========================

  final String companyName;
  final String legalCompanyName;
  final String industry;
  final String companySize;
  final String country;
  final String state;
  final String city;
  final String address;
  final String postalCode;
  final String website;
  final String description;
  final String logoUrl;

  // =========================
  // Step 2 : Subscription
  // =========================

  final String plan;
  final int employeeLimit;
  final int storageLimit;
  final int projectLimit;

  // =========================
  // Step 3 : Admin Details
  // =========================

  final String ownerName;
  final String email;
  final String password;
  final String phone;

  // =========================
  // Step 4 : Company Settings
  // =========================

  final String timezone;
  final String language;
  final String currency;

  // =========================
  // Step 5 : Tax Details
  // =========================

  final String gstNumber;
  final String panNumber;

  // =========================
  // Step 6 : Modules
  // =========================

  final bool enableProjects;
  final bool enableTimeline;
  final bool enableAppraisal;
  final bool enableReports;
  final bool enableNotifications;

  const CompanyRequestModel({
    // Company
    required this.companyName,
    this.legalCompanyName = '',
    this.industry = '',
    this.companySize = '',
    required this.country,
    this.state = '',
    this.city = '',
    this.address = '',
    this.postalCode = '',
    this.website = '',
    this.description = '',
    this.logoUrl = '',

    // Subscription
    required this.plan,
    required this.employeeLimit,
    required this.storageLimit,
    this.projectLimit = 100,

    // Admin
    required this.ownerName,
    required this.email,
    required this.password,
    this.phone = '',

    // Settings
    this.timezone = 'Asia/Kolkata',
    this.language = 'en',
    this.currency = 'INR',

    // Tax
    this.gstNumber = '',
    this.panNumber = '',

    // Modules
    this.enableProjects = true,
    this.enableTimeline = true,
    this.enableAppraisal = false,
    this.enableReports = true,
    this.enableNotifications = true,
  });

  Map<String, dynamic> toMap() {
    return {
      // Company
      'companyName': companyName,
      'legalCompanyName': legalCompanyName,
      'industry': industry,
      'companySize': companySize,
      'country': country,
      'state': state,
      'city': city,
      'address': address,
      'postalCode': postalCode,
      'website': website,
      'description': description,
      'logoUrl': logoUrl,

      // Subscription
      'plan': plan,
      'employeeLimit': employeeLimit,
      'storageLimit': storageLimit,
      'projectLimit': projectLimit,

      // Admin
      'ownerName': ownerName,
      'email': email,
      'password': password,
      'phone': phone,

      // Settings
      'timezone': timezone,
      'language': language,
      'currency': currency,

      // Tax
      'gstNumber': gstNumber,
      'panNumber': panNumber,

      // Modules
      'modules': {
        'projects': enableProjects,
        'timeline': enableTimeline,
        'appraisal': enableAppraisal,
        'reports': enableReports,
        'notifications': enableNotifications,
      },

      // Metadata
      'status': 'active',
      'createdAt': DateTime.now().toIso8601String(),
    };
  }

  factory CompanyRequestModel.fromMap(Map<String, dynamic> map) {
    final modules = (map['modules'] ?? {}) as Map<String, dynamic>;

    return CompanyRequestModel(
      companyName: map['companyName'] ?? '',
      legalCompanyName: map['legalCompanyName'] ?? '',
      industry: map['industry'] ?? '',
      companySize: map['companySize'] ?? '',
      country: map['country'] ?? '',
      state: map['state'] ?? '',
      city: map['city'] ?? '',
      address: map['address'] ?? '',
      postalCode: map['postalCode'] ?? '',
      website: map['website'] ?? '',
      description: map['description'] ?? '',
      logoUrl: map['logoUrl'] ?? '',
      plan: map['plan'] ?? '',
      employeeLimit: map['employeeLimit'] ?? 0,
      storageLimit: map['storageLimit'] ?? 0,
      projectLimit: map['projectLimit'] ?? 100,
      ownerName: map['ownerName'] ?? '',
      email: map['email'] ?? '',
      password: map['password'] ?? '',
      phone: map['phone'] ?? '',
      timezone: map['timezone'] ?? 'Asia/Kolkata',
      language: map['language'] ?? 'en',
      currency: map['currency'] ?? 'INR',
      gstNumber: map['gstNumber'] ?? '',
      panNumber: map['panNumber'] ?? '',
      enableProjects: modules['projects'] ?? true,
      enableTimeline: modules['timeline'] ?? true,
      enableAppraisal: modules['appraisal'] ?? false,
      enableReports: modules['reports'] ?? true,
      enableNotifications: modules['notifications'] ?? true,
    );
  }

  String toJson() => jsonEncode(toMap());

  factory CompanyRequestModel.fromJson(String source) =>
      CompanyRequestModel.fromMap(jsonDecode(source));

  CompanyRequestModel copyWith({
    String? companyName,
    String? legalCompanyName,
    String? industry,
    String? companySize,
    String? country,
    String? state,
    String? city,
    String? address,
    String? postalCode,
    String? website,
    String? description,
    String? logoUrl,
    String? plan,
    int? employeeLimit,
    int? storageLimit,
    int? projectLimit,
    String? ownerName,
    String? email,
    String? password,
    String? phone,
    String? timezone,
    String? language,
    String? currency,
    String? gstNumber,
    String? panNumber,
    bool? enableProjects,
    bool? enableTimeline,
    bool? enableAppraisal,
    bool? enableReports,
    bool? enableNotifications,
  }) {
    return CompanyRequestModel(
      companyName: companyName ?? this.companyName,
      legalCompanyName: legalCompanyName ?? this.legalCompanyName,
      industry: industry ?? this.industry,
      companySize: companySize ?? this.companySize,
      country: country ?? this.country,
      state: state ?? this.state,
      city: city ?? this.city,
      address: address ?? this.address,
      postalCode: postalCode ?? this.postalCode,
      website: website ?? this.website,
      description: description ?? this.description,
      logoUrl: logoUrl ?? this.logoUrl,
      plan: plan ?? this.plan,
      employeeLimit: employeeLimit ?? this.employeeLimit,
      storageLimit: storageLimit ?? this.storageLimit,
      projectLimit: projectLimit ?? this.projectLimit,
      ownerName: ownerName ?? this.ownerName,
      email: email ?? this.email,
      password: password ?? this.password,
      phone: phone ?? this.phone,
      timezone: timezone ?? this.timezone,
      language: language ?? this.language,
      currency: currency ?? this.currency,
      gstNumber: gstNumber ?? this.gstNumber,
      panNumber: panNumber ?? this.panNumber,
      enableProjects: enableProjects ?? this.enableProjects,
      enableTimeline: enableTimeline ?? this.enableTimeline,
      enableAppraisal: enableAppraisal ?? this.enableAppraisal,
      enableReports: enableReports ?? this.enableReports,
      enableNotifications:
          enableNotifications ?? this.enableNotifications,
    );
  }
}