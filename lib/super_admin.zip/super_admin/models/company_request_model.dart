import 'dart:convert';

class CompanyRequestModel {
  // Step 1: Company Details
  final String companyName;
  final String country;

  // Step 2: Allocation & Subscription Limits
  final String plan; 
  final int employeeLimit;
  final int storageLimit; 

  // Step 3: Global Identity & Contact
  final String ownerName;
  final String email;
  final String? phone;

  // Step 4: Component Feature Flags (SDUI Toggles)
  final bool enableProjects;
  final bool enableTimeline;
  final bool enableAppraisal;
  final bool enableReports;
  final bool enableNotifications;

  CompanyRequestModel({
    required this.companyName,
    required this.country,
    required this.plan,
    required this.employeeLimit,
    required this.storageLimit,
    required this.ownerName,
    required this.email,
    this.phone,
    this.enableProjects = true,
    this.enableTimeline = true,
    this.enableAppraisal = false,
    this.enableReports = true,
    this.enableNotifications = true,
  });

  /// Maps the internal properties directly to the backend API keys.
  Map<String, dynamic> toMap() {
    return {
      'companyName': companyName,
      'country': country,
      'plan': plan,
      'employeeLimit': employeeLimit,
      'storageLimit': storageLimit,
      'ownerName': ownerName,
      'email': email,
      'phone': phone ?? '',
      'modules': {
        'projects': enableProjects,
        'timeline': enableTimeline,
        'appraisal': enableAppraisal,
        'reports': enableReports,
        'notifications': enableNotifications,
      }
    };
  }

  /// Serializes the map structure into a JSON string payload.
  String toJson() => json.encode(toMap());
}