import 'package:flutter/material.dart';
import 'package:project_management_dashboard/super_admin/services/super_admin_api_service.dart';

class WizardStateProvider extends ChangeNotifier {
  int _currentStep = 0;
  bool _isSubmitting = false;
  String errorMessage = '';

  // Form Data (Steps 1-3)
  String companyName = '';
  String industry = 'Technology';
  String plan = 'Free Allocation (Max limit: 10 accounts)';
  String email = '';
  String password = '';

  // Module Toggles (Step 4)
  bool enableTasks = true;
  bool enableTeams = true;
  bool enableChat = true;
  bool enableAnalytics = true;

  int get currentStep => _currentStep;
  bool get isSubmitting => _isSubmitting;

  void nextStep() {
    if (_currentStep < 4) {
      _currentStep++;
      errorMessage = '';
      notifyListeners();
    }
  }

  void previousStep() {
    if (_currentStep > 0) {
      _currentStep--;
      errorMessage = ''; 
      notifyListeners();
    }
  }

  void setStep(int step) {
    _currentStep = step;
    notifyListeners();
  }

  // Toggle handler for Step 4
  void toggleModule(String module, bool value) {
    if (module == 'tasks') enableTasks = value;
    if (module == 'teams') enableTeams = value;
    if (module == 'chat') enableChat = value;
    if (module == 'analytics') enableAnalytics = value;
    notifyListeners();
  }

  Future<bool> submitCompany() async {
    _isSubmitting = true;
    errorMessage = ''; 
    notifyListeners();

    try {
      // Structure fields into distinct variables for standard rules check
      String cleanTier = plan.contains('Free') ? 'free' : 'pro';
      int maxLimit = plan.contains('Free') ? 10 : -1; // -1 represents unlimited

      final apiService = SuperAdminApiService();
      await apiService.provisionNewCompany(
        companyName: companyName,
        industry: industry,
        adminEmail: email,
        adminPassword: password,
        planInfo: {
          'tier': cleanTier,
          'maxUsersLimit': maxLimit,
          'features': {
            'tasks': enableTasks,
            'teams': enableTeams,
            'chat': enableChat,
            'analytics': enableAnalytics,
          }
        },
      );
      
      _isSubmitting = false;
      _currentStep = 0; // Reset the wizard back to the start upon success
      notifyListeners();
      return true;
      
    } catch (e) {
      _isSubmitting = false;
      // Strip out the generic Exception text to make the UI look professional
      errorMessage = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      return false;
    }
  }
}