import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../firebase_options.dart'; 

class SuperAdminApiService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> provisionNewCompany({
    required String companyName,
    required String industry,
    required String adminEmail,
    required String adminPassword,
    required Map<String, dynamic> planInfo,
  }) async {
    try {
      // 1. Authenticate user creation directly via Google Identity Toolkit REST API
      final String apiKey = DefaultFirebaseOptions.web.apiKey;
      final Uri url = Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey');

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': adminEmail,
          'password': adminPassword,
          'returnSecureToken': false,
        }),
      );

      final responseData = json.decode(response.body);

      // 2. Handle API Errors gracefully
      if (response.statusCode != 200) {
        String errorMsg = responseData['error']['message'] ?? 'Unknown Auth Error';
        if (errorMsg.contains('EMAIL_EXISTS')) {
          throw Exception('This email is already registered in the system.');
        } else if (errorMsg.contains('WEAK_PASSWORD')) {
          throw Exception('The password is too weak (minimum 6 characters).');
        } else if (errorMsg.contains('INVALID_EMAIL')) {
          throw Exception('Please enter a valid email address.');
        }
        throw Exception(errorMsg);
      }

      // 3. Extract generated UID
      String newUid = responseData['localId'];

      // 4. Run Transactional Firestore Writes
      WriteBatch batch = _db.batch();
      String companyId = 'company_${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';

      batch.set(_db.collection('companies').doc(companyId), {
        'name': companyName,
        'industry': industry,
        'createdAt': FieldValue.serverTimestamp(),
        'status': 'active',
      });

      batch.set(_db.collection('companies').doc(companyId).collection('members').doc(newUid), {
        'uid': newUid,
        'email': adminEmail,
        'role': 'superAdmin',
        'status': 'active',
      });

      batch.set(_db.collection('companies').doc(companyId).collection('settings').doc('bootstrap'), {
        ...planInfo,
        'enabled': true,
        'version': 1,
      });

      await batch.commit();
      
    } catch (e) {
      String cleanError = e.toString().replaceAll('Exception: ', '');
      if (cleanError.contains('permission-denied')) {
        cleanError = "Access Denied: Verify your master account has 'platformSuperAdmin' clearance.";
      }
      throw Exception(cleanError); 
    }
  }
}