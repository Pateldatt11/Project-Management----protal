import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wizard_state_provider.dart';

class SuperAdminWizardScreen extends StatelessWidget {
  const SuperAdminWizardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<WizardStateProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Create New Company Profile"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      backgroundColor: const Color(0xFFF5F6FA),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Theme(
              data: Theme.of(context).copyWith(
                colorScheme: const ColorScheme.light(
                  primary: Color(0xFF673AB7),
                ),
              ),
              child: Stepper(
                type: StepperType.vertical,
                currentStep: state.currentStep,
                onStepTapped: (step) => state.setStep(step),
                onStepContinue: state.currentStep < 4 ? state.nextStep : null,
                onStepCancel: state.currentStep > 0 ? state.previousStep : null,
                controlsBuilder: (context, details) {
                  if (state.currentStep == 4) return const SizedBox.shrink();
                  
                  return Padding(
                    padding: const EdgeInsets.only(top: 24.0),
                    child: Row(
                      children: [
                        ElevatedButton(
                          onPressed: details.onStepContinue,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF673AB7),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                          ),
                          child: const Text('Continue'),
                        ),
                        const SizedBox(width: 16),
                        if (state.currentStep > 0)
                          TextButton(
                            onPressed: details.onStepCancel,
                            child: const Text('Back', style: TextStyle(color: Colors.grey)),
                          ),
                      ],
                    ),
                  );
                },
                steps: [
                  _buildStep1(state),
                  _buildStep2(state),
                  _buildStep3(state),
                  _buildStep4(state),
                  _buildStep5(context, state),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Step _buildStep1(WizardStateProvider state) {
    return Step(
      title: const Text('Company Information', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 0,
      state: state.currentStep > 0 ? StepState.complete : StepState.indexed,
      content: Column(
        children: [
          TextFormField(
            initialValue: state.companyName,
            decoration: const InputDecoration(labelText: 'Target Workspace Name', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.companyName = val,
          ),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: state.industry,
            decoration: const InputDecoration(labelText: 'Industry Sector', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.industry = val,
          ),
        ],
      ),
    );
  }

  Step _buildStep2(WizardStateProvider state) {
    return Step(
      title: const Text('Subscription Plan & Constraints', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 1,
      state: state.currentStep > 1 ? StepState.complete : StepState.indexed,
      content: DropdownButtonFormField<String>(
        value: state.plan,
        decoration: const InputDecoration(border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
        items: const [
          DropdownMenuItem(value: 'Free Allocation (Max limit: 10 accounts)', child: Text('Free Allocation (Max limit: 10 accounts)')),
          DropdownMenuItem(value: 'Pro Tier (Unlimited Accounts)', child: Text('Pro Tier (Unlimited Accounts)')),
        ],
        onChanged: (val) {
          if (val != null) state.plan = val;
        },
      ),
    );
  }

  Step _buildStep3(WizardStateProvider state) {
    return Step(
      title: const Text('Primary Account Executive Account', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 2,
      state: state.currentStep > 2 ? StepState.complete : StepState.indexed,
      content: Column(
        children: [
          TextFormField(
            initialValue: state.email,
            decoration: const InputDecoration(labelText: 'Admin Email Address', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.email = val,
          ),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: state.password,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Initial Password', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
            onChanged: (val) => state.password = val,
          ),
        ],
      ),
    );
  }

  Step _buildStep4(WizardStateProvider state) {
    return Step(
      title: const Text('Initialize Modules Framework', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 3,
      state: state.currentStep > 3 ? StepState.complete : StepState.indexed,
      content: const Padding(
        padding: EdgeInsets.symmetric(vertical: 8.0),
        child: Text(
          "Core UI rendering parameters will auto-bind following successfully deployed settings initialization documents.",
          style: TextStyle(color: Colors.grey, fontSize: 14),
        ),
      ),
    );
  }

  Step _buildStep5(BuildContext context, WizardStateProvider state) {
    return Step(
      title: const Text('Review System Parameters', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      isActive: state.currentStep >= 4,
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Text("Target Workspace: ${state.companyName}", style: const TextStyle(fontSize: 15, height: 1.8)),
          Text("Assigned Tier: ${state.plan}", style: const TextStyle(fontSize: 15, height: 1.8)),
          Text("Infrastructure Owner: [${state.email}]", style: const TextStyle(fontSize: 15, height: 1.8)),
          const SizedBox(height: 12),
          const Text(
            "Please ensure all input validation tokens map correctly before initializing remote initialization.",
            style: TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 24),

          if (state.errorMessage.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 24),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.1),
                border: Border.all(color: Colors.redAccent),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.redAccent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      state.errorMessage,
                      style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ],

          Row(
            children: [
              SizedBox(
                height: 48,
                width: 140,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF673AB7),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: state.isSubmitting 
                      ? null 
                      : () async {
                          bool success = await state.submitCompany();
                          if (success && context.mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Workspace Provisioned Successfully!")),
                            );
                          }
                        },
                  child: state.isSubmitting 
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) 
                      : const Text("Continue"),
                ),
              ),
              const SizedBox(width: 16),
              TextButton(
                onPressed: () => state.previousStep(),
                child: const Text("Back", style: TextStyle(color: Colors.grey)),
              )
            ],
          ),
        ],
      ),
    );
  }
}