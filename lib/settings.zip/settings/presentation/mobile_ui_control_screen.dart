import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/workspace_state.dart';
import '../../../core/permissions/permission_service.dart';
import '../../../core/widgets/section_card.dart';
import '../../../core/widgets/status_badge.dart';
import '../../../data/models/mobile_ui_config.dart';

class MobileUiControlScreen extends ConsumerStatefulWidget {
  const MobileUiControlScreen({super.key});

  @override
  ConsumerState<MobileUiControlScreen> createState() => _MobileUiControlScreenState();
}

class _MobileUiControlScreenState extends ConsumerState<MobileUiControlScreen> {
  late bool _enabled;
  late bool _compactMode;
  late Set<String> _bottomTabs;
  late Set<String> _homeCards;
  late Set<String> _taskFields;
  late Set<String> _projectFields;
  late String _taskCardVariant;
  late String _projectCardVariant;
  late bool _showFloatingTaskTabs;
  late bool _newArrivalsFirst;
  late bool _showCompletedTaskTab;
  late String _taskDefaultTab;
  late String _taskCompletedSort;
  late String _topNavStyle;
  late bool _topNavShowInbox;
  late bool _topNavInboxBadge;
  late bool _topNavShowCompany;
  late bool _topNavShowRole;
  late bool _topNavShowPresence;
  late bool _topNavShowAvatar;
  late bool _topNavPresenceGlow;
  late bool _profileShowLogout;
  late String _profileLogoutStyle;
  late String _profileLogoutPosition;
  int _loadedConfigVersion = -1;

  @override
  void initState() {
    super.initState();
    _applyConfig(ref.read(workspaceProvider).mobileUiConfig);
  }

  void _applyConfig(MobileUiConfig config) {
    _loadedConfigVersion = config.version;
    _enabled = config.enabled;
    _compactMode = config.compactMode;
    _bottomTabs = config.bottomTabs.toSet();
    _homeCards = config.homeCards.toSet();
    _taskFields = config.taskCardFields.toSet();
    _projectFields = config.projectCardFields.toSet();
    _taskCardVariant = MobileUiConfig.allowedCardVariants.contains(config.taskCardVariant) ? config.taskCardVariant : 'modernCard';
    _projectCardVariant = MobileUiConfig.allowedCardVariants.contains(config.projectCardVariant) ? config.projectCardVariant : 'progressCard';
    _showFloatingTaskTabs = config.taskListConfig['showFloatingTabs'] != false;
    _newArrivalsFirst = config.taskListConfig['newArrivalFirst'] != false;
    _showCompletedTaskTab = config.taskListConfig['showCompletedTab'] != false;
    _taskDefaultTab = const <String>['newArrival', 'completed'].contains(config.taskListConfig['defaultTab']?.toString()) ? config.taskListConfig['defaultTab'].toString() : 'newArrival';
    _taskCompletedSort = const <String>['completedAtDesc', 'updatedAtDesc'].contains(config.taskListConfig['completedSort']?.toString()) ? config.taskListConfig['completedSort'].toString() : 'completedAtDesc';
    _topNavStyle = config.topNav['style']?.toString() ?? 'glassAdvanced';
    _topNavShowInbox = config.topNav['showInbox'] != false;
    _topNavInboxBadge = config.topNav['inboxBadge'] != false;
    _topNavShowCompany = config.topNav['showCompanyName'] != false;
    _topNavShowRole = config.topNav['showUserRole'] != false;
    _topNavShowPresence = config.topNav['showOnlineStatus'] != false;
    _topNavShowAvatar = config.topNav['showAvatar'] != false;
    _topNavPresenceGlow = config.topNav['showPresenceGlow'] != false;
    _profileShowLogout = config.profileActions['showLogout'] != false;
    _profileLogoutStyle = const <String>['filledIcon', 'v145MatchedPillGrid', 'capsule', 'outlined', 'text'].contains(config.profileActions['logoutStyle']?.toString()) ? config.profileActions['logoutStyle'].toString() : 'filledIcon';
    _profileLogoutPosition = const <String>['bottom', 'profileHeader', 'actionsRow', 'profileActionButton'].contains(config.profileActions['logoutPosition']?.toString()) ? config.profileActions['logoutPosition'].toString() : 'bottom';
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(workspaceProvider);
    if (state.mobileUiConfig.version != _loadedConfigVersion) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        setState(() => _applyConfig(ref.read(workspaceProvider).mobileUiConfig));
      });
    }
    final canManage = PermissionService.canManageSettings(state.currentMember);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile UI Control'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: StatusBadge(label: _enabled ? 'Enabled' : 'Disabled', color: _enabled ? Colors.green : Colors.orange)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            SectionCard(
              title: 'Server-driven employee mobile UI',
              subtitle: 'Control employee app tabs, home cards, task fields, and project fields from Firestore. Employees receive updates without an APK rebuild.',
              child: Column(
                children: [
                  SwitchListTile(
                    value: _enabled,
                    onChanged: canManage ? (value) => setState(() => _enabled = value) : null,
                    title: const Text('Enable mobile UI config'),
                    subtitle: const Text('When off, the employee app uses built-in default mobile layout.'),
                  ),
                  SwitchListTile(
                    value: _compactMode,
                    onChanged: canManage ? (value) => setState(() => _compactMode = value) : null,
                    title: const Text('Compact mobile mode'),
                    subtitle: const Text('Reduces spacing and card height for smaller phones.'),
                  ),
                  const Divider(height: 18),
                  DropdownButtonFormField<String>(
                    initialValue: const <String>['glassAdvanced', 'premium', 'glass', 'floating', 'compact', 'standard'].contains(_topNavStyle) ? _topNavStyle : 'glassAdvanced',
                    decoration: const InputDecoration(labelText: 'Top nav style'),
                    items: const <DropdownMenuItem<String>>[
                      DropdownMenuItem(value: 'glassAdvanced', child: Text('Glass advanced capsule')),
                      DropdownMenuItem(value: 'premium', child: Text('Premium glass capsule')),
                      DropdownMenuItem(value: 'glass', child: Text('Simple glass capsule')),
                      DropdownMenuItem(value: 'floating', child: Text('Floating clean capsule')),
                      DropdownMenuItem(value: 'compact', child: Text('Compact capsule')),
                      DropdownMenuItem(value: 'standard', child: Text('Standard')),
                    ],
                    onChanged: canManage ? (value) => setState(() => _topNavStyle = value ?? 'glassAdvanced') : null,
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilterChip(label: const Text('Inbox'), selected: _topNavShowInbox, onSelected: canManage ? (value) => setState(() => _topNavShowInbox = value) : null),
                      FilterChip(label: const Text('Inbox badge'), selected: _topNavInboxBadge, onSelected: canManage ? (value) => setState(() => _topNavInboxBadge = value) : null),
                      FilterChip(label: const Text('Company'), selected: _topNavShowCompany, onSelected: canManage ? (value) => setState(() => _topNavShowCompany = value) : null),
                      FilterChip(label: const Text('Role'), selected: _topNavShowRole, onSelected: canManage ? (value) => setState(() => _topNavShowRole = value) : null),
                      FilterChip(label: const Text('Presence'), selected: _topNavShowPresence, onSelected: canManage ? (value) => setState(() => _topNavShowPresence = value) : null),
                      FilterChip(label: const Text('Avatar'), selected: _topNavShowAvatar, onSelected: canManage ? (value) => setState(() => _topNavShowAvatar = value) : null),
                      FilterChip(label: const Text('Glow'), selected: _topNavPresenceGlow, onSelected: canManage ? (value) => setState(() => _topNavPresenceGlow = value) : null),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SectionCard(
              title: 'Profile actions',
              subtitle: 'Keep logout on the Profile page and control whether it is shown in the employee APK.',
              trailing: StatusBadge(label: _profileShowLogout ? 'Logout in Profile' : 'Hidden', color: Colors.redAccent),
              child: Column(
                children: [
                  SwitchListTile(
                    value: _profileShowLogout,
                    onChanged: canManage ? (value) => setState(() => _profileShowLogout = value) : null,
                    title: const Text('Show Logout button inside Profile'),
                    subtitle: const Text('Top nav logout remains off; this keeps the UI cleaner.'),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _profileLogoutStyle,
                    decoration: const InputDecoration(labelText: 'Profile logout style'),
                    items: const [
                      DropdownMenuItem(value: 'filledIcon', child: Text('Same as Edit Profile')),
                      DropdownMenuItem(value: 'v145MatchedPillGrid', child: Text('Matched pill grid')),
                      DropdownMenuItem(value: 'capsule', child: Text('Capsule')),
                      DropdownMenuItem(value: 'outlined', child: Text('Outlined')),
                      DropdownMenuItem(value: 'text', child: Text('Text button')),
                    ],
                    onChanged: canManage ? (value) => setState(() => _profileLogoutStyle = value ?? 'filledIcon') : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: _profileLogoutPosition,
                    decoration: const InputDecoration(labelText: 'Profile logout position'),
                    items: const [
                      DropdownMenuItem(value: 'bottom', child: Text('Bottom of Profile')),
                      DropdownMenuItem(value: 'profileHeader', child: Text('Profile header')),
                      DropdownMenuItem(value: 'actionsRow', child: Text('Action row')),
                      DropdownMenuItem(value: 'profileActionButton', child: Text('Profile action button grid')),
                    ],
                    onChanged: canManage ? (value) => setState(() => _profileLogoutPosition = value ?? 'bottom') : null,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _ChoiceSection(
              title: 'Bottom navigation tabs',
              subtitle: 'Choose which tabs appear in the employee Android/iOS app.',
              values: MobileUiConfig.allowedBottomTabs,
              labels: _labels,
              selected: _bottomTabs,
              canManage: canManage,
              onChanged: (value) => setState(() => _bottomTabs = value),
            ),
            const SizedBox(height: 18),
            _ChoiceSection(
              title: 'Employee home cards',
              subtitle: 'Choose and order-safe cards for the employee home screen.',
              values: MobileUiConfig.allowedHomeCards,
              labels: _labels,
              selected: _homeCards,
              canManage: canManage,
              onChanged: (value) => setState(() => _homeCards = value),
            ),
            const SizedBox(height: 18),
            _ChoiceSection(
              title: 'Task card fields',
              subtitle: 'Choose which fields the mobile task/project-task cards can show.',
              values: MobileUiConfig.allowedTaskCardFields,
              labels: _labels,
              selected: _taskFields,
              canManage: canManage,
              onChanged: (value) => setState(() => _taskFields = value),
            ),
            const SizedBox(height: 18),
            SectionCard(
              title: 'Task card visual style',
              subtitle: 'This dropdown now publishes the task card variant to Firestore and the APK renderer uses it in production.',
              trailing: StatusBadge(label: _variantLabel(_taskCardVariant), color: Colors.deepPurple),
              child: DropdownButtonFormField<String>(
                initialValue: MobileUiConfig.allowedCardVariants.contains(_taskCardVariant) ? _taskCardVariant : 'modernCard',
                decoration: const InputDecoration(labelText: 'Task card dropdown design'),
                items: _variantItems(),
                onChanged: canManage ? (value) => setState(() => _taskCardVariant = value ?? 'modernCard') : null,
              ),
            ),
            const SizedBox(height: 18),
            SectionCard(
              title: 'Task menu filter',
              subtitle: 'Control the employee Tasks tab. New/open tasks are sorted by latest arrival and completed tasks move to a separate floating tab.',
              trailing: StatusBadge(label: _showFloatingTaskTabs ? 'Floating tabs' : 'Single list', color: Colors.deepPurple),
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    initialValue: _taskDefaultTab,
                    decoration: const InputDecoration(labelText: 'Default task tab'),
                    items: const [
                      DropdownMenuItem(value: 'newArrival', child: Text('New arrival')),
                      DropdownMenuItem(value: 'completed', child: Text('Completed')),
                    ],
                    onChanged: canManage ? (value) => setState(() => _taskDefaultTab = value ?? 'newArrival') : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: _taskCompletedSort,
                    decoration: const InputDecoration(labelText: 'Completed task sort'),
                    items: const [
                      DropdownMenuItem(value: 'completedAtDesc', child: Text('Completed date newest first')),
                      DropdownMenuItem(value: 'updatedAtDesc', child: Text('Last updated newest first')),
                    ],
                    onChanged: canManage ? (value) => setState(() => _taskCompletedSort = value ?? 'completedAtDesc') : null,
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    value: _showFloatingTaskTabs,
                    onChanged: canManage ? (value) => setState(() => _showFloatingTaskTabs = value) : null,
                    title: const Text('Show floating New / Completed tabs'),
                    subtitle: const Text('Adds a capsule filter at the top of the Tasks screen.'),
                  ),
                  SwitchListTile(
                    value: _newArrivalsFirst,
                    onChanged: canManage ? (value) => setState(() => _newArrivalsFirst = value) : null,
                    title: const Text('New arrivals first'),
                    subtitle: const Text('Sorts open tasks by createdAt/updatedAt newest first.'),
                  ),
                  SwitchListTile(
                    value: _showCompletedTaskTab,
                    onChanged: canManage ? (value) => setState(() => _showCompletedTaskTab = value) : null,
                    title: const Text('Show completed task tab'),
                    subtitle: const Text('Completed tasks are separated from the new arrival list.'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _ChoiceSection(
              title: 'Project card fields',
              subtitle: 'Choose which fields employee project cards can show.',
              values: MobileUiConfig.allowedProjectCardFields,
              labels: _labels,
              selected: _projectFields,
              canManage: canManage,
              onChanged: (value) => setState(() => _projectFields = value),
            ),
            const SizedBox(height: 18),
            SectionCard(
              title: 'Project card visual style',
              subtitle: 'This dropdown now publishes the project card variant to Firestore and the APK renderer uses it in production.',
              trailing: StatusBadge(label: _variantLabel(_projectCardVariant), color: Colors.teal),
              child: DropdownButtonFormField<String>(
                initialValue: MobileUiConfig.allowedCardVariants.contains(_projectCardVariant) ? _projectCardVariant : 'progressCard',
                decoration: const InputDecoration(labelText: 'Project card dropdown design'),
                items: _variantItems(),
                onChanged: canManage ? (value) => setState(() => _projectCardVariant = value ?? 'progressCard') : null,
              ),
            ),
            const SizedBox(height: 18),
            SectionCard(
              title: 'Preview summary',
              subtitle: 'This is what will be saved to companies/${state.company.companyId}/uiConfigs/mobileEmployee.',
              trailing: FilledButton.icon(
                onPressed: canManage ? _save : null,
                icon: const Icon(Icons.cloud_done_rounded),
                label: const Text('Save mobile UI'),
              ),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatusBadge(label: '${_bottomTabs.length} tabs', color: Colors.blue),
                  StatusBadge(label: '${_homeCards.length} home cards', color: Colors.indigo),
                  StatusBadge(label: '${_taskFields.length} task fields', color: Colors.deepPurple),
                  StatusBadge(label: _variantLabel(_taskCardVariant), color: Colors.deepPurple),
                  StatusBadge(label: '${_projectFields.length} project fields', color: Colors.teal),
                  StatusBadge(label: _variantLabel(_projectCardVariant), color: Colors.teal),
                  StatusBadge(label: _showFloatingTaskTabs ? 'New/Done task tabs' : 'No task tabs', color: Colors.deepPurple),
                  StatusBadge(label: _compactMode ? 'Compact' : 'Comfortable', color: Colors.blueGrey),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _save() {
    final config = MobileUiConfig(
      enabled: _enabled,
      version: ref.read(workspaceProvider).mobileUiConfig.version + 1,
      bottomTabs: _ordered(MobileUiConfig.allowedBottomTabs, _bottomTabs),
      topNav: <String, dynamic>{
        'enabled': true,
        'style': _topNavStyle,
        'density': _compactMode ? 'compact' : 'comfortable',
        'showInbox': _topNavShowInbox,
        'showCompanyName': _topNavShowCompany,
        'showUserRole': _topNavShowRole,
        'showOnlineStatus': _topNavShowPresence,
        'showLogout': false,
        'inboxBadge': _topNavInboxBadge,
        'showAvatar': _topNavShowAvatar,
        'showPresenceGlow': _topNavPresenceGlow,
      },
      homeCards: _ordered(MobileUiConfig.allowedHomeCards, _homeCards),
      taskCardFields: _ordered(MobileUiConfig.allowedTaskCardFields, _taskFields),
      projectCardFields: _ordered(MobileUiConfig.allowedProjectCardFields, _projectFields),
      taskCardVariant: MobileUiConfig.allowedCardVariants.contains(_taskCardVariant) ? _taskCardVariant : 'modernCard',
      projectCardVariant: MobileUiConfig.allowedCardVariants.contains(_projectCardVariant) ? _projectCardVariant : 'progressCard',
      taskListConfig: <String, dynamic>{
        'showFloatingTabs': _showFloatingTaskTabs,
        'defaultTab': _taskDefaultTab,
        'newArrivalFirst': _newArrivalsFirst,
        'showCompletedTab': _showCompletedTaskTab,
        'completedSort': _taskCompletedSort,
      },
      profileActions: <String, dynamic>{
        'showLogout': _profileShowLogout,
        'logoutStyle': _profileLogoutStyle,
        'logoutPosition': _profileLogoutPosition,
        'setOfflineBeforeLogout': true,
      },
      compactMode: _compactMode,
    );
    ref.read(workspaceProvider.notifier).updateMobileUiConfig(config);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Employee mobile UI config saved.')));
  }

  static List<String> _ordered(List<String> allowed, Set<String> selected) {
    final values = allowed.where(selected.contains).toList();
    return values.isEmpty ? allowed.take(1).toList() : values;
  }


  static List<DropdownMenuItem<String>> _variantItems() {
    return MobileUiConfig.allowedCardVariants
        .map((variant) => DropdownMenuItem<String>(value: variant, child: Text(_variantLabel(variant))))
        .toList();
  }

  static String _variantLabel(String value) {
    return switch (value) {
      'modernCard' => 'Modern card',
      'minimalCard' => 'Minimal card',
      'compactCard' => 'Compact card',
      'timelineCard' => 'Timeline card',
      'progressCard' => 'Progress card',
      'advancedProgressCard' => 'Advanced progress card',
      _ => value,
    };
  }

  static String _labels(String value) {
    return switch (value) {
      'home' => 'Home',
      'tasks' => 'Tasks',
      'projects' => 'Projects',
      'board' => 'Board',
      'notifications' => 'Inbox',
      'profile' => 'Profile',
      'deadlineTimer' => 'Deadline timer',
      'myOpenTasks' => 'My open tasks',
      'todayTasks' => 'Today tasks',
      'projectProgress' => 'Project progress',
      'onlineStatus' => 'Online status',
      'projectName' => 'Project name',
      'taskTitle' => 'Task title',
      'status' => 'Status',
      'priority' => 'Priority',
      'progress' => 'Progress',
      'statusTag' => 'Status tag',
      'description' => 'Description',
      'assignedBy' => 'Assigned by',
      'commentsCount' => 'Comments count',
      'filesCount' => 'Files count',
      'attachmentsCount' => 'Attachments count',
      'assigneeCount' => 'Assignee count',
      'taskCount' => 'Task count',
      'deadline' => 'Deadline',
      'team' => 'Team',
      'teamCount' => 'Team count',
      'completedTaskCount' => 'Completed task count',
      _ => value,
    };
  }
}

class _ChoiceSection extends StatelessWidget {
  const _ChoiceSection({
    required this.title,
    required this.subtitle,
    required this.values,
    required this.labels,
    required this.selected,
    required this.canManage,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final List<String> values;
  final String Function(String value) labels;
  final Set<String> selected;
  final bool canManage;
  final ValueChanged<Set<String>> onChanged;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: title,
      subtitle: subtitle,
      trailing: StatusBadge(label: '${selected.length}/${values.length}', color: Colors.blueGrey),
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: values.map((value) {
          final active = selected.contains(value);
          return FilterChip(
            selected: active,
            label: Text(labels(value)),
            onSelected: canManage
                ? (next) {
                    final copy = selected.toSet();
                    if (next) {
                      copy.add(value);
                    } else {
                      copy.remove(value);
                    }
                    onChanged(copy);
                  }
                : null,
          );
        }).toList(),
      ),
    );
  }
}
